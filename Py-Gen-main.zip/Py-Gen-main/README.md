# How to add accounts?
Make the txt file in the Accounts folder. Thats it lol

# Py Gen
A website gen based on python, html and javascript. The backend of the site is made entirely with python, this makes it so that the database is not made public making it secure.

# Note
People can abuse this system by using proxies or clearing their session everytime they gen to bypass the cooldown. To fix this, you could make a login system or add recaptcha to the site. If you need help, message me on discord:
- Name: MickeyYe#0001
- UserID: 847917077641953340

# Features
- Rate limiting (Gen Cooldown)
- Nice gui
- Easy to add stock
- Account removes from stock after generating
- Made in python
- Comments in code to be easier to understand

# Requirements
```
pip install -r requirements.txt
```

# License
```
MIT License

Copyright (c) 2021 Mickey

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```